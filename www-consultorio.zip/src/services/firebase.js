// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCB08KWz4-HH0dpaEsU4OJtuGmWxm5KwOc",
  authDomain: "av2-devweb.firebaseapp.com",
  databaseURL: "https://av2-devweb-default-rtdb.firebaseio.com",
  projectId: "av2-devweb",
  storageBucket: "av2-devweb.appspot.com",
  messagingSenderId: "262616025428",
  appId: "1:262616025428:web:fd2dadb0bbdd1ac60da0c1"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

