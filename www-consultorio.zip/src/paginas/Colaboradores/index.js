
import React from "react";
import Login from "../../componentes/Login";
import EstruturaPagina from '../../componentes/EstruturaPagina';


export default class Colaboradores extends React.Component {
    render() {
        return (
            <EstruturaPagina>
            
            <Login/>

            </EstruturaPagina>
        );
               
    }
}